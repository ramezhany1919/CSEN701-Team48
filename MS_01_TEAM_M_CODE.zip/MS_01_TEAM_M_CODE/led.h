#ifndef LED_H
#define LED_H

#include "pico/stdlib.h"

// GPIO pin numbers for the LEDs
extern const uint RED_LED_PIN;
extern const uint GREEN_LED_PIN;
extern const uint BLUE_LED_PIN;

// Function declarations
void initialize_leds(void);
void turn_on_led(uint pin);
void turn_off_led(uint pin);
void turn_on_blue_led(void);
void turn_off_blue_led(void);

#endif // LED_H
