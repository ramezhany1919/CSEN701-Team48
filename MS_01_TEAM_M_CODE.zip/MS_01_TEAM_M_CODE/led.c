#include "led.h"

// Define GPIO pin numbers for the LEDs
const uint RED_LED_PIN = 4;     // GPIO pin for the Red LED
const uint GREEN_LED_PIN = 7;   // GPIO pin for the Green LED
const uint BLUE_LED_PIN = 5;    // GPIO pin for the Blue LED (Negative logic)

void initialize_leds() {
    // Initialize the GPIO pins for each LED
    gpio_init(RED_LED_PIN);
    gpio_set_dir(RED_LED_PIN, GPIO_OUT);
    gpio_init(GREEN_LED_PIN);
    gpio_set_dir(GREEN_LED_PIN, GPIO_OUT);

    // Initialize the Blue LED with negative logic
    gpio_init(BLUE_LED_PIN);
    gpio_set_dir(BLUE_LED_PIN, GPIO_OUT);
   
}

void turn_on_led(uint pin) {
    gpio_put(pin, true);
}

void turn_off_led(uint pin) {
    gpio_put(pin, false);
}

void turn_on_blue_led() {
    // For negative logic LED, turning on means setting the pin LOW
    gpio_put(BLUE_LED_PIN, false);
}

void turn_off_blue_led() {
    // For negative logic LED, turning off means setting the pin HIGH
    gpio_put(BLUE_LED_PIN, true);
}
