#include "led.h"

int main() {
    stdio_init_all(); // Initialize all configured stdio types
    initialize_leds(); // Setup LED pins

    while (true) {
        // Start with all LEDs off for 5 seconds
        turn_off_led(RED_LED_PIN);
        turn_off_led(GREEN_LED_PIN);
        turn_off_blue_led();
        sleep_ms(5000);

        // Sequence to turn each LED on for 1 second and then off
        turn_on_led(RED_LED_PIN);
        sleep_ms(1000);
        turn_off_led(RED_LED_PIN);

        turn_on_led(GREEN_LED_PIN);
        sleep_ms(1000);
        turn_off_led(GREEN_LED_PIN);

        turn_on_blue_led();
        sleep_ms(1000);
        turn_off_blue_led();

        // Turn all LEDs on for 2 seconds
        turn_on_led(RED_LED_PIN);
        turn_on_led(GREEN_LED_PIN);
        turn_on_blue_led();
        sleep_ms(2000);

        turn_off_led(RED_LED_PIN);
        turn_off_led(GREEN_LED_PIN);
        turn_off_blue_led();
    }

    return 0;
}
